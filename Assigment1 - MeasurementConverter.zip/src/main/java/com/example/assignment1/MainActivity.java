package com.example.assignment1;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button button;
    Spinner spinner;
    String choice;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button)findViewById(R.id.button);
        spinner = (Spinner)findViewById(R.id.spinner_FC);

// Inside your onCreate() method or initialization
        EditText editText = findViewById(R.id.editTextNumber);
        Spinner spinner = findViewById(R.id.spinner_FC);
        Button button = findViewById(R.id.button);
        TextView resultText = findViewById(R.id.result);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = editText.getText().toString();

                if (inputText.isEmpty()) {
                    resultText.setText("Please enter a number!");
                    return;
                }

                double input = Double.parseDouble(inputText); // Convert input to number
                double result = 0.0;

                // Get selected conversion type
                String selectedConversion = spinner.getSelectedItem().toString();

                // Conversion logic
                switch (selectedConversion) {
                    case "Centimeters → Meters":
                        result = input / 100;
                        break;
                    case "Meters → Kilometers":
                        result = input / 1000;
                        break;
                    case "Celsius → Fahrenheit -":
                        result = (input * 9/5) + 32;
                        break;
                    case "Fahrenheit → Celsius":
                        result = (input - 32) * 5/9;
                        break;
                    case "Grams → Kilograms":
                        result = input / 1000;
                        break;
                    default:
                        resultText.setText("Invalid selection");
                        return;
                }

                // Display result
                resultText.setText("Result: " + result);
            }
        });

        
        ArrayAdapter<CharSequence> adapter=
                ArrayAdapter.createFromResource(this,
                        R.array.FC_array,
                        android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                choice=(String)parent.getItemAtPosition(position);
                Toast.makeText(context,choice,Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //not Selected
            }
        });

    }
}